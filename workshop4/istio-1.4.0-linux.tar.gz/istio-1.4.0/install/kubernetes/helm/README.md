# Installation using Helm

Please follow the installation instructions from [istio.io](https://istio.io/docs/setup/kubernetes/install/helm/).

## Development

Future development for the installer is taking place on [istio/installer](https://github.com/istio/installer). Please add new features to that repository, as only bug fixes will be allowed here.